# -*- coding: utf-8 -*-

import random
from PIL import Image
import os


def add_white_pixel_randomly(image_path, output_path):
    img = Image.open(image_path).convert("RGB")  # 转换为 RGB 格式

    width, height = img.size
    random_x = random.randint(0, width - 1)
    random_y = random.randint(0, height - 1)

    img.putpixel((random_x, random_y), (255, 255, 255))  # 在随机位置添加一个白色像素
    img.save(output_path, format='jpeg')  # 保存为 JPEG 格式

print "start update rotate..."
for f in os.listdir("/opt/cdnfly/nginx/conf/rotate/"):
    input_jpeg = "/opt/cdnfly/nginx/conf/rotate-origin/" + f
    output_jpeg = "/opt/cdnfly/nginx/conf/rotate/" + f

    add_white_pixel_randomly(input_jpeg, output_jpeg)

print "update rotate done."